# Love Dog's — site vitrine

Site vitrine une page pour **Love Dog's** (partenaire canin en Guadeloupe) : éducation canine, dog sitting et nutrition. HTML / CSS / JavaScript natif, sans framework ni étape de build. Il fonctionne tel quel dans n'importe quel navigateur et se met en ligne sur n'importe quel hébergeur.

Design clair et aéré, fond porcelaine chaud, accents or et anthracite, motif patte de chien comme fil conducteur, micro-interactions au survol.

---

## Arborescence

```
love-dogs/
├── index.html          Page unique (contenu, SEO, données structurées)
├── css/style.css       Styles (palette claire, mise en page, animations, responsive)
├── js/main.js          Menu mobile, header au scroll, révélations au défilement
├── mentions-legales.html   Mentions légales (éditeur, hébergeur, RGPD)
├── infos-a-completer.html  Page de travail : questions à poser (NE PAS mettre en ligne)
├── css/style.css
├── js/main.js
├── assets/
│   ├── logo.png        Logo officiel Love Dog's (blason)
│   ├── hero.jpg / education.jpg / sitting.jpg   Photos d'ambiance
│   └── og-image.png    Image d'aperçu réseaux sociaux
├── favicon.png         Icône d'onglet (logo)
├── robots.txt
├── sitemap.xml
└── README.md
```

---

## Voir le site en local

Double-cliquer sur `index.html`, ou lancer un petit serveur :

```bash
python3 -m http.server 8000     # puis ouvrir http://localhost:8000
```

---

## Mettre en ligne sur GitHub

1. Créer un dépôt (ex. `love-dogs`).
2. Déposer **le contenu** de ce dossier (le `index.html` doit être à la racine du dépôt).
3. Aperçu gratuit : **GitHub Pages** (Settings, Pages, branche `main`, dossier `/root`) ou **Vercel / Netlify** (import du dépôt, aucun réglage de build).
4. Mise en ligne finale chez le client : upload via OVH / FileZilla à la racine, une fois `love-dogs.fr` transféré.

---

## Photos

Les 3 photos d'ambiance sont intégrées (`assets/hero.jpg`, `assets/education.jpg`, `assets/sitting.jpg`), recadrées au format exact de chaque emplacement. Pour en changer une, remplacer le fichier en gardant le même nom, ou modifier le chemin dans `css/style.css` (blocs `.photo-hero`, `.photo-edu`, `.photo-sit`). Format conseillé : portrait pour le héro, paysage pour les deux autres.

**Visuels des sacs de croquettes** : les 4 sacs de la section Nutrition sont des illustrations vectorielles (SVG) dessinées directement dans `index.html`, une couleur par produit (Énergie rouge, Ultra Énergie noir, Wild Spirit doré, Sport bronze). Elles s'affichent toujours, sans dépendre d'un fichier image. Pour changer un nom ou une couleur, modifier le bloc SVG correspondant dans la section `#nutrition`.

---

## Logo

Le logo officiel Love Dog's (le blason) est intégré partout : header, footer, favicon et image de partage. Il est stocké dans `assets/logo.png`. Pour le mettre à jour, remplacer ce fichier en gardant le même nom.

---

## Coordonnées

Numéro, WhatsApp et email apparaissent à plusieurs endroits : `tel:+590690302359`, `https://wa.me/590690302359`, `lovedogs971@gmail.com`. Un simple rechercher / remplacer dans `index.html` suffit si un contact change.

---

## Référencement (SEO)

Déjà en place : `title`, meta description, mots-clés, Open Graph (partage réseaux), `sitemap.xml`, `robots.txt` et surtout les **données structurées `LocalBusiness`** (JSON-LD) avec téléphone, email et zone Guadeloupe.

À faire ensuite pour « apparaître en premier » :
1. **Créer la fiche Google Business Profile** (le client n'en a pas) : c'est le levier n°1 pour la visibilité locale en Guadeloupe.
2. Mettre en ligne sur le domaine définitif puis déclarer le site dans **Google Search Console** (soumettre le `sitemap.xml`).
3. Remplacer les URL `https://www.love-dogs.fr/` dans `index.html`, `sitemap.xml` et `robots.txt` si le domaine final diffère.

---

## Détails techniques

- Aucune dépendance externe hors polices Google (Great Vibes, Sora, Inter).
- Accessible : navigation clavier, focus visible, lien d'évitement, `prefers-reduced-motion` respecté.
- Responsive du mobile au grand écran, bouton WhatsApp flottant sur mobile.

---

## Sections et fonctionnalités

- **Header** : les 3 services (éducation, dog sitting, nutrition) sont présentés dès l'arrivée, sous forme de bandeau cliquable, pour qu'un visiteur qui scanne le QR code comprenne immédiatement l'offre.
- **Tarifs dog sitting** : deux formules claires (1 ou 2 visites/jour) avec compteurs animés, plus les options (promenade, chien supplémentaire, déplacement).
- **Nutrition** : les 4 références sont présentées avec les photos officielles des sacs (détourées sur fond transparent), les taux de protéines et matières grasses, et le prix au sac de 20 kg. Commande par WhatsApp, pas d'abonnement.

## Mentions légales et infos à compléter

`mentions-legales.html` est **obligatoire** pour un site professionnel (loi LCEN). Elle est renseignée avec les informations officielles de l'entreprise (Alexandre AL LAYOUS, EI, SIREN 808 990 824, SIRET 808 990 824 00019, APE 4776Z, Mare Gaillard 97190 Le Gosier), l'hébergeur OVH et la réalisation Novalem. La page est publiable en l'état : seule la ligne TVA reste à activer, elle est écrite et commentée dans le code au repère `<!-- MODIFIER -->`.

`infos-a-completer.html` est une **page de travail** qui liste les questions à poser au client pour tout compléter. Elle n'est liée nulle part et ne doit pas être mise en ligne : à supprimer une fois les mentions légales finalisées.

Les **CGV** ont été retirées : elles ne sont pas obligatoires pour un site vitrine sans vente en ligne. À ajouter seulement si des ventes en ligne sont mises en place plus tard.

Le lien de crédit « Novalem » en pied de page pointe vers `https://novalem-recrutement.fr` ; le domaine du site dans `sitemap.xml` (`love-dogs.fr`) est un exemple à adapter au domaine réel.
